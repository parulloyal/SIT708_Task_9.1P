package com.example.task71;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.Manifest;

import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.task71.databinding.ActivityLostFoundBinding;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LostFoundActivity extends AppCompatActivity {
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    private ActivityLostFoundBinding binding;
    private List<LostFoundData> itemList;
    private double latitude;
    private double longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLostFoundBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        itemList = new ArrayList<>();
        binding.rLost.setChecked(true);

        binding.tvGetCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if location permission is granted
                if (ContextCompat.checkSelfPermission(LostFoundActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(LostFoundActivity.this,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            LOCATION_PERMISSION_REQUEST_CODE);
                } else {
                    // Check if location services are enabled
                    LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        // Location services are disabled, show toast
                        Toast.makeText(LostFoundActivity.this, "Please enable location service", Toast.LENGTH_SHORT).show();
                    } else {
                        // Location services are enabled, proceed to request location updates
                        requestLocationUpdates();
                    }
                }
            }
        });

        binding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton checkedRadioButton = findViewById(checkedId);
                if (checkedRadioButton.getId() == R.id.r_lost) {
                } else if (checkedRadioButton.getId() == R.id.r_found) {
                }
            }
        });
        binding.tvSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateFields()) {
                    saveData();
                }
            }
        });
    }

    private boolean validateFields() {
        if (binding.radioGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select Lost or Found", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(binding.etName.getText().toString().trim())) {
            binding.warningName.setVisibility(View.VISIBLE);
            return false;
        } else {
            binding.warningName.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(binding.etPhone.getText().toString().trim())) {
            binding.warningPhone.setVisibility(View.VISIBLE);
            return false;
        } else {
            binding.warningPhone.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(binding.etDescription.getText().toString().trim())) {
            binding.warningDescription.setVisibility(View.VISIBLE);
            return false;
        } else {
            binding.warningDescription.setVisibility(View.GONE);
        }

        String date = binding.etDate.getText().toString().trim();
        if (TextUtils.isEmpty(date)) {
            binding.warningDate.setVisibility(View.VISIBLE);
            return false;
        } else {
            if (!isValidDateFormat(date)) {
                binding.warningDate.setVisibility(View.GONE);
                Toast.makeText(this, "Invalid date format (yyyy/mm/dd)", Toast.LENGTH_SHORT).show();
                return false;
            }
            binding.warningDate.setVisibility(View.GONE);
        }

        if (TextUtils.isEmpty(binding.etLocation.getText().toString().trim())) {
            binding.warningLocation.setVisibility(View.VISIBLE);
            return false;
        } else {
            binding.warningLocation.setVisibility(View.GONE);
        }
        return true;
    }

    private void saveData() {
        int radioButtonId = binding.radioGroup.getCheckedRadioButtonId();
        if (radioButtonId == -1) {
            Toast.makeText(this, "Please select Lost or Found", Toast.LENGTH_SHORT).show();
            return;
        }

        RadioButton radioButton = findViewById(radioButtonId);
        String type = radioButton.getText().toString();

        String name = binding.etName.getText().toString().trim();
        String phone = binding.etPhone.getText().toString().trim();
        String description = binding.etDescription.getText().toString().trim();
        String date = binding.etDate.getText().toString().trim();
        String location = binding.etLocation.getText().toString().trim();
//        double latitude = 0.0;
//        double longitude = 0.0;
//        String address = binding.etLocation.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(description)
                || TextUtils.isEmpty(date) || TextUtils.isEmpty(location)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("itemList", "");
        Gson gson = new Gson();
        Type typeToken = new TypeToken<List<LostFoundData>>() {
        }.getType();
        List<LostFoundData> itemList;
        if (!json.isEmpty()) {
            itemList = gson.fromJson(json, typeToken);
        } else {
            itemList = new ArrayList<>();
        }

        LostFoundData item = new LostFoundData();
        item.setType(type);
        item.setName(name);
        item.setPhone(phone);
        item.setDescription(description);
        item.setDate(date);
        item.setLocation(location);
        item.setLatitude(latitude); // Set latitude
        item.setLongitude(longitude); // Set longitude
        Log.d("Check", String.valueOf(latitude));
//        item.setAddress(address);

        itemList.add(item);
        String updatedJson = gson.toJson(itemList);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("itemList", updatedJson);
        editor.apply();
        Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show();
        finish();
    }

    private boolean isValidDateFormat(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
        sdf.setLenient(false); // Ensure strict date parsing
        try {
            Date date = sdf.parse(dateStr);
            // Date parsing succeeded, so the format is valid
            return true;
        } catch (ParseException e) {
            // Date parsing failed, indicating an invalid format
            return false;
        }
    }

    private void requestLocationUpdates() {
        // Create location request
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10000);
        final LostFoundData item = new LostFoundData();// Update location every 10 seconds

        // Create location callback
        LocationCallback locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                if (locationResult != null) {
                    Location location = locationResult.getLastLocation();
                    if (location != null) {
                        // Handle the received location
                         latitude = location.getLatitude();
                         longitude = location.getLongitude();

                        // Use Geocoder to get the address from latitude and longitude
                        Geocoder geocoder = new Geocoder(LostFoundActivity.this, Locale.getDefault());
                        try {
                            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                            if (addresses != null && addresses.size() > 0) {
                                Address address = addresses.get(0);
                                String addressLine = address.getAddressLine(0); // Get the first address line

                                // Set the address to the location EditText
                                binding.etLocation.setText(addressLine);

                                // Set latitude and longitude to the corresponding fields of the item
                                // (assuming you have access to the item variable)
                                item.setLatitude(latitude);
                                item.setLongitude(longitude);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        };

        // Request location updates
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed to request location updates
                requestLocationUpdates();
            } else {
                // Permission denied, show a message or handle accordingly
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}