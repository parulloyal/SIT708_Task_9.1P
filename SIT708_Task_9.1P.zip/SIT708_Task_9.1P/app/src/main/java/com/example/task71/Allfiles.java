package com.example.task71;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task71.databinding.ActivityHomeBinding;
import com.example.task71.databinding.ActivityItemDetailsBinding;
import com.example.task71.databinding.ActivityItemListBinding;
import com.example.task71.databinding.ActivityLostFoundBinding;
import com.example.task71.databinding.ItemListBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Allfiles {

    package com.example.task71;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.task71.databinding.ActivityHomeBinding;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

    public class HomeActivity extends AppCompatActivity {
        private ActivityHomeBinding binding;
        private static final int YOUR_REQUEST_CODE = 1;
        private GoogleMap googleMap;
        private List<LatLng> latLngList = new ArrayList<>();
        private MapView mapView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            binding = ActivityHomeBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String json = sharedPreferences.getString("itemList", "");


            if (!json.isEmpty()) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<LostFoundData>>() {}.getType();
                List<LostFoundData> itemList = gson.fromJson(json, type);

                if (itemList != null && !itemList.isEmpty()) {

                }
            } else {
                Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
            }

            binding.tvNew.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(com.example.task71.HomeActivity.this, LostFoundActivity.class);
                    startActivity(intent);
                }
            });

            binding.tvLost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(com.example.task71.HomeActivity.this, ItemListActivity.class);
                    startActivity(intent);
                }
            });
            binding.tvShowOnMap.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(v.getContext(), "Need google map api key!", Toast.LENGTH_SHORT).show();
                    //showMapWithMarkers();
                }
            });
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == YOUR_REQUEST_CODE && resultCode == RESULT_OK) {
                if (data != null) {
                    double latitude = data.getDoubleExtra("latitude", 0.0);
                    double longitude = data.getDoubleExtra("longitude", 0.0);
                    String latLngListJson = data.getStringExtra("latLngListJson");

                    // Retrieve the updated list of latitude and longitude values from SharedPreferences
                    SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                    Gson gson = new Gson();
                    Type type = new TypeToken<List<Double>>() {}.getType();
                    List<Double> latLngList = gson.fromJson(latLngListJson, type);

                    // Now you have latitude and longitude values and the updated list of all latitude and longitude values
                    // Use them as needed
                }
            }
        }

        private void showMapWithMarkers() {
            // Retrieve all latitude and longitude values from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            Set<String> latLngSet = sharedPreferences.getStringSet("latLngList", new HashSet<>());

            List<Double> latLngValues = new ArrayList<>();
            for (String value : latLngSet) {
                latLngValues.add(Double.valueOf(value));
            }

            // Convert latitude and longitude values to LatLng objects
            latLngList.clear();
            for (int i = 0; i < latLngValues.size(); i += 2) {
                double latitude = latLngValues.get(i);
                double longitude = latLngValues.get(i + 1);
                LatLng latLng = new LatLng(latitude, longitude);
                latLngList.add(latLng);
            }

            // Initialize the map fragment
            SupportMapFragment mapFragment = new SupportMapFragment();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.map_container, mapFragment)
                    .commit();

            // Set up map
            mapFragment.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap map) {
                    googleMap = map;

                    // Clear previous markers
                    googleMap.clear();

                    // Add markers for each latitude and longitude with address
                    for (LatLng latLng : latLngList) {
                        MarkerOptions markerOptions = new MarkerOptions().position(latLng);
                        try {
                            Geocoder geocoder = new Geocoder(com.example.task71.HomeActivity.this, Locale.getDefault());
                            List<Address> addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                            if (!addresses.isEmpty()) {
                                String address = addresses.get(0).getAddressLine(0);
                                markerOptions.title(address);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        googleMap.addMarker(markerOptions);
                    }

                    // Zoom to fit all markers
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    for (LatLng latLng : latLngList) {
                        builder.include(latLng);
                    }
                    LatLngBounds bounds = builder.build();
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 200);
                    googleMap.moveCamera(cameraUpdate);
                }
            });
        }
    }
package com.example.task71;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.task71.databinding.ActivityItemDetailsBinding;
import com.google.gson.Gson;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

    public class ItemDetailsActivity extends AppCompatActivity {
        private ActivityItemDetailsBinding binding;
        private List<LostFoundData> itemList;
        private static final int ITEM_DELETED_RESULT_CODE = 1001;
        private ItemListAdapter adapter;


        private int position;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            binding = ActivityItemDetailsBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            itemList = (List<LostFoundData>) getIntent().getSerializableExtra("itemList");
            position = getIntent().getIntExtra("position", -1);

            if (itemList != null && position != -1 && position < itemList.size()) {
                LostFoundData clickedItem = itemList.get(position);
                binding.tvName.setText("-- Name: "+clickedItem.getName());
                binding.tvPhone.setText("-- Phone: "+clickedItem.getPhone());
                binding.tvDescription.setText("-- Description: "+clickedItem.getDescription());
                binding.tvDate.setText("-- Date: "+getDateDifference(clickedItem.getDate()));
                binding.tvLocation.setText("-- Location: "+clickedItem.getLocation());
                binding.tvRemove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onDeleteButtonClick();
                    }
                });
            } else {
                Toast.makeText(this, "Error: Unable to retrieve item details", Toast.LENGTH_SHORT).show();
                finish();
            }
        }

        private void onDeleteButtonClick() {
            if (position != -1 && position < itemList.size()) {
                itemList.remove(position);
                updateSharedPreferences();
                setResult(ITEM_DELETED_RESULT_CODE); // Set result indicating item deletion
                Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        }

        private void updateSharedPreferences() {
            Gson gson = new Gson();
            String json = gson.toJson(itemList);
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("itemList", json);
            editor.apply();
        }
//    private String getDateDifference(String date) {
//        // Parse the date from the string, assuming it's in the format "yyyy/MM/dd"
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
//        try {
//            Date itemDate = sdf.parse(date);
//            Date currentDate = new Date(); // Current date
//
//            // Calculate the difference in milliseconds
//            long differenceInMillis = currentDate.getTime() - itemDate.getTime();
//
//            // Convert milliseconds to days
//            long differenceInDays = TimeUnit.MILLISECONDS.toDays(differenceInMillis);
//
//            // Calculate difference in terms of months and years
//            long differenceInMonths = differenceInDays / 30;
//            long differenceInYears = differenceInMonths / 12;
//
//            // Format the output based on the difference
//            if (differenceInYears > 0) {
//                return differenceInYears + (differenceInYears == 1 ? " year ago" : " years ago");
//            } else if (differenceInMonths > 0) {
//                return differenceInMonths + (differenceInMonths == 1 ? " month ago" : " months ago");
//            } else if (differenceInDays > 0) {
//                return differenceInDays + (differenceInDays == 1 ? " day ago" : " days ago");
//            } else {
//                return "Today";
//            }
//        } catch (ParseException e) {
//            e.printStackTrace();
//            return date; // Return the original date if there's an error
//        }
//    }


        public static String getDateDifference(String date) {
            DateTimeFormatter formatter = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            }
            try {
                LocalDate itemDate = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    itemDate = LocalDate.parse(date, formatter);
                }
                LocalDate currentDate = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    currentDate = LocalDate.now();
                }

                // Calculate the difference using Period
                Period period = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    period = Period.between(itemDate, currentDate);
                }

                long years = 0;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    years = period.getYears();
                }
                long months = 0;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    months = period.getMonths();
                }
                long days = 0;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    days = period.getDays();
                }

                StringBuilder differenceString = new StringBuilder();

                if (years > 0) {
                    differenceString.append(years).append(years == 1 ? " year " : " years ");
                }
                if (months > 0) {
                    differenceString.append(months).append(months == 1 ? " month " : " months ");
                }
                if (days > 0) {
                    differenceString.append(days).append(days == 1 ? " day " : " days ");
                }

                // If the difference string is empty, it means the date is today
                if (differenceString.length() == 0) {
                    return "Today";
                }

                // Append "ago" at the end of the difference string
                differenceString.append("ago");

                return differenceString.toString().trim();
            } catch (Exception e) {
                e.printStackTrace();
                return date; // Return the original date if there's an error
            }
        }
    }
package com.example.task71;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task71.databinding.ActivityItemListBinding;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;

    public class ItemListActivity extends AppCompatActivity {
        private ActivityItemListBinding binding;
        private RecyclerView recyclerView;
        private ItemListAdapter adapter;
        private static final int ITEM_DELETED_RESULT_CODE = 1001;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            binding = ActivityItemListBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            recyclerView = binding.rvItemList;
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String json = sharedPreferences.getString("itemList", "");

            if (!json.isEmpty()) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<LostFoundData>>() {}.getType();
                List<LostFoundData> itemList = gson.fromJson(json, type);

                if (itemList != null && !itemList.isEmpty()) {
                    adapter = new ItemListAdapter(this, itemList);
                    recyclerView.setAdapter(adapter);
                } else {
                    binding.tvNoData.setVisibility(View.VISIBLE);
                }
            } else {
                Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == ITEM_DELETED_RESULT_CODE && resultCode == RESULT_OK) {
                adapter.notifyDataSetChanged();
                // Refresh data and update RecyclerView
                refreshItemList();
            }
        }

        private void refreshItemList() {
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String json = sharedPreferences.getString("itemList", "");

            if (!json.isEmpty()) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<LostFoundData>>() {}.getType();
                List<LostFoundData> itemList = gson.fromJson(json, type);

                if (itemList != null && !itemList.isEmpty()) {
                    Collections.reverse(itemList);
                    adapter = new ItemListAdapter(this, itemList);
                    recyclerView.setAdapter(adapter);
                } else {
                    binding.tvNoData.setVisibility(View.VISIBLE);
                }
            } else {
                binding.tvNoData.setVisibility(View.VISIBLE);
            }
        }
        @Override
        protected void onResume() {
            refreshItemList();
            super.onResume();
        }

        @Override
        protected void onRestart() {
            refreshItemList();
            super.onRestart();
        }

        @Override
        protected void onPause() {
            refreshItemList();
            super.onPause();
        }
    }

package com.example.task71;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.task71.databinding.ItemListBinding;

import java.io.Serializable;
import java.util.List;

    public class ItemListAdapter extends RecyclerView.Adapter<com.example.task71.ItemListAdapter.ViewHolder> {
        private List<LostFoundData> itemList;
        private Context context;

        public ItemListAdapter(Context context, List<LostFoundData> itemList) {
            this.context = context;
            this.itemList = itemList;
        }

        @NonNull
        @Override
        public com.example.task71.ItemListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemListBinding binding = ItemListBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new com.example.task71.ItemListAdapter.ViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull com.example.task71.ItemListAdapter.ViewHolder holder, int position) {
            LostFoundData item = itemList.get(position);
            holder.bind(item);
        }

        @Override
        public int getItemCount() {
            return itemList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            private ItemListBinding binding;

            public ViewHolder(@NonNull ItemListBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
                binding.getRoot().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            LostFoundData clickedItem = itemList.get(position);
                            Intent intent = new Intent(context, com.example.task71.ItemDetailsActivity.class);
                            intent.putExtra("itemList", (Serializable) itemList);
                            intent.putExtra("position", position);
                            context.startActivity(intent);
                        }
                    }
                });
            }

            public void bind(LostFoundData item) {
                if (item.getName() != null) {
                    binding.tvType.setText(item.getType());
                    binding.tvName.setText(item.getName());
                } else {
                    binding.tvName.setText("Unknown Name");
                }
            }
        }
    }
package com.example.task71;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.Manifest;

import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.task71.databinding.ActivityLostFoundBinding;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

    public class LostFoundActivity extends AppCompatActivity {
        private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

        private ActivityLostFoundBinding binding;
        private List<LostFoundData> itemList;
        private double latitude;
        private double longitude;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            binding = ActivityLostFoundBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());
            itemList = new ArrayList<>();
            binding.rLost.setChecked(true);

            binding.tvGetCurrentLocation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Check if location permission is granted
                    if (ContextCompat.checkSelfPermission(com.example.task71.LostFoundActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(com.example.task71.LostFoundActivity.this,
                                new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                                LOCATION_PERMISSION_REQUEST_CODE);
                    } else {
                        // Check if location services are enabled
                        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            // Location services are disabled, show toast
                            Toast.makeText(com.example.task71.LostFoundActivity.this, "Please enable location service", Toast.LENGTH_SHORT).show();
                        } else {
                            // Location services are enabled, proceed to request location updates
                            requestLocationUpdates();
                        }
                    }
                }
            });

            binding.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    RadioButton checkedRadioButton = findViewById(checkedId);
                    if (checkedRadioButton.getId() == R.id.r_lost) {
                    } else if (checkedRadioButton.getId() == R.id.r_found) {
                    }
                }
            });
            binding.tvSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (validateFields()) {
                        saveData();
                    }
                }
            });
        }

        private boolean validateFields() {
            if (binding.radioGroup.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "Please select Lost or Found", Toast.LENGTH_SHORT).show();
                return false;
            }
            if (TextUtils.isEmpty(binding.etName.getText().toString().trim())) {
                binding.warningName.setVisibility(View.VISIBLE);
                return false;
            } else {
                binding.warningName.setVisibility(View.GONE);
            }

            if (TextUtils.isEmpty(binding.etPhone.getText().toString().trim())) {
                binding.warningPhone.setVisibility(View.VISIBLE);
                return false;
            } else {
                binding.warningPhone.setVisibility(View.GONE);
            }

            if (TextUtils.isEmpty(binding.etDescription.getText().toString().trim())) {
                binding.warningDescription.setVisibility(View.VISIBLE);
                return false;
            } else {
                binding.warningDescription.setVisibility(View.GONE);
            }

            String date = binding.etDate.getText().toString().trim();
            if (TextUtils.isEmpty(date)) {
                binding.warningDate.setVisibility(View.VISIBLE);
                return false;
            } else {
                if (!isValidDateFormat(date)) {
                    binding.warningDate.setVisibility(View.GONE);
                    Toast.makeText(this, "Invalid date format (yyyy/mm/dd)", Toast.LENGTH_SHORT).show();
                    return false;
                }
                binding.warningDate.setVisibility(View.GONE);
            }

            if (TextUtils.isEmpty(binding.etLocation.getText().toString().trim())) {
                binding.warningLocation.setVisibility(View.VISIBLE);
                return false;
            } else {
                binding.warningLocation.setVisibility(View.GONE);
            }
            return true;
        }

        private void saveData() {
            int radioButtonId = binding.radioGroup.getCheckedRadioButtonId();
            if (radioButtonId == -1) {
                Toast.makeText(this, "Please select Lost or Found", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton radioButton = findViewById(radioButtonId);
            String type = radioButton.getText().toString();

            String name = binding.etName.getText().toString().trim();
            String phone = binding.etPhone.getText().toString().trim();
            String description = binding.etDescription.getText().toString().trim();
            String date = binding.etDate.getText().toString().trim();
            String location = binding.etLocation.getText().toString().trim();
//        double latitude = 0.0;
//        double longitude = 0.0;
//        String address = binding.etLocation.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(description)
                    || TextUtils.isEmpty(date) || TextUtils.isEmpty(location)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String json = sharedPreferences.getString("itemList", "");
            Gson gson = new Gson();
            Type typeToken = new TypeToken<List<LostFoundData>>() {
            }.getType();
            List<LostFoundData> itemList;
            if (!json.isEmpty()) {
                itemList = gson.fromJson(json, typeToken);
            } else {
                itemList = new ArrayList<>();
            }

            LostFoundData item = new LostFoundData();
            item.setType(type);
            item.setName(name);
            item.setPhone(phone);
            item.setDescription(description);
            item.setDate(date);
            item.setLocation(location);
            item.setLatitude(latitude); // Set latitude
            item.setLongitude(longitude); // Set longitude
            Log.d("Check", String.valueOf(latitude));
//        item.setAddress(address);

            itemList.add(item);
            String updatedJson = gson.toJson(itemList);

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("itemList", updatedJson);
            editor.apply();
            Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show();
            finish();
        }

        private boolean isValidDateFormat(String dateStr) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
            sdf.setLenient(false); // Ensure strict date parsing
            try {
                Date date = sdf.parse(dateStr);
                // Date parsing succeeded, so the format is valid
                return true;
            } catch (ParseException e) {
                // Date parsing failed, indicating an invalid format
                return false;
            }
        }

        private void requestLocationUpdates() {
            // Create location request
            LocationRequest locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(10000);
            final LostFoundData item = new LostFoundData();// Update location every 10 seconds

            // Create location callback
            LocationCallback locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                    if (locationResult != null) {
                        Location location = locationResult.getLastLocation();
                        if (location != null) {
                            // Handle the received location
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();

                            // Use Geocoder to get the address from latitude and longitude
                            Geocoder geocoder = new Geocoder(com.example.task71.LostFoundActivity.this, Locale.getDefault());
                            try {
                                List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                                if (addresses != null && addresses.size() > 0) {
                                    Address address = addresses.get(0);
                                    String addressLine = address.getAddressLine(0); // Get the first address line

                                    // Set the address to the location EditText
                                    binding.etLocation.setText(addressLine);

                                    // Set latitude and longitude to the corresponding fields of the item
                                    // (assuming you have access to the item variable)
                                    item.setLatitude(latitude);
                                    item.setLongitude(longitude);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            };

            // Request location updates
            FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        }



        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, proceed to request location updates
                    requestLocationUpdates();
                } else {
                    // Permission denied, show a message or handle accordingly
                    Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    package com.example.task71;

import java.io.Serializable;

    public class LostFoundData implements Serializable {
        private String type;
        private String name;
        private String phone;
        private String description;
        private String date;
        private String location;
        private double latitude;
        private double longitude;

        public LostFoundData() {
            // Default constructor required for Firestore
        }

        public LostFoundData(String type, String name, String phone, String description, String date, String location) {
            this.type = type;
            this.name = name;
            this.phone = phone;
            this.description = description;
            this.date = date;
            this.location = location;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public double getLatitude() {
            return latitude;
        }

        public void setLatitude(double latitude) {
            this.latitude = latitude;
        }

        public double getLongitude() {
            return longitude;
        }

        public void setLongitude(double longitude) {
            this.longitude = longitude;
        }
        public String getAddress() {
            return location;
        }

        public void setAddress(String location) {
            this.location = location;
        }
    }

}
