package com.example.task71;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.task71.databinding.ActivityHomeBinding;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class HomeActivity extends AppCompatActivity {
    private ActivityHomeBinding binding;
    private static final int YOUR_REQUEST_CODE = 1;
    private GoogleMap googleMap;
    private List<LatLng> latLngList = new ArrayList<>();
    private MapView mapView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("itemList", "");


        if (!json.isEmpty()) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<LostFoundData>>() {}.getType();
            List<LostFoundData> itemList = gson.fromJson(json, type);

            if (itemList != null && !itemList.isEmpty()) {

            }
        } else {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }

        binding.tvNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, LostFoundActivity.class);
                startActivity(intent);
            }
        });

        binding.tvLost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, ItemListActivity.class);
                startActivity(intent);
            }
        });
        binding.tvShowOnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "Need google map api key!", Toast.LENGTH_SHORT).show();
                //showMapWithMarkers();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == YOUR_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                double latitude = data.getDoubleExtra("latitude", 0.0);
                double longitude = data.getDoubleExtra("longitude", 0.0);
                String latLngListJson = data.getStringExtra("latLngListJson");

                // Retrieve the updated list of latitude and longitude values from SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                Gson gson = new Gson();
                Type type = new TypeToken<List<Double>>() {}.getType();
                List<Double> latLngList = gson.fromJson(latLngListJson, type);

                // Now you have latitude and longitude values and the updated list of all latitude and longitude values
                // Use them as needed
            }
        }
    }

    private void showMapWithMarkers() {
        // Retrieve all latitude and longitude values from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        Set<String> latLngSet = sharedPreferences.getStringSet("latLngList", new HashSet<>());

        List<Double> latLngValues = new ArrayList<>();
        for (String value : latLngSet) {
            latLngValues.add(Double.valueOf(value));
        }

        // Convert latitude and longitude values to LatLng objects
        latLngList.clear();
        for (int i = 0; i < latLngValues.size(); i += 2) {
            double latitude = latLngValues.get(i);
            double longitude = latLngValues.get(i + 1);
            LatLng latLng = new LatLng(latitude, longitude);
            latLngList.add(latLng);
        }

        // Initialize the map fragment
        SupportMapFragment mapFragment = new SupportMapFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.map_container, mapFragment)
                .commit();

        // Set up map
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap map) {
                googleMap = map;

                // Clear previous markers
                googleMap.clear();

                // Add markers for each latitude and longitude with address
                for (LatLng latLng : latLngList) {
                    MarkerOptions markerOptions = new MarkerOptions().position(latLng);
                    try {
                        Geocoder geocoder = new Geocoder(HomeActivity.this, Locale.getDefault());
                        List<Address> addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
                        if (!addresses.isEmpty()) {
                            String address = addresses.get(0).getAddressLine(0);
                            markerOptions.title(address);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    googleMap.addMarker(markerOptions);
                }

                // Zoom to fit all markers
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                for (LatLng latLng : latLngList) {
                    builder.include(latLng);
                }
                LatLngBounds bounds = builder.build();
                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 200);
                googleMap.moveCamera(cameraUpdate);
            }
        });
    }
}
