package com.example.task71;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task71.databinding.ActivityItemListBinding;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;

public class ItemListActivity extends AppCompatActivity {
    private ActivityItemListBinding binding;
    private RecyclerView recyclerView;
    private ItemListAdapter adapter;
    private static final int ITEM_DELETED_RESULT_CODE = 1001;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityItemListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        recyclerView = binding.rvItemList;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("itemList", "");

        if (!json.isEmpty()) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<LostFoundData>>() {}.getType();
            List<LostFoundData> itemList = gson.fromJson(json, type);

            if (itemList != null && !itemList.isEmpty()) {
                adapter = new ItemListAdapter(this, itemList);
                recyclerView.setAdapter(adapter);
            } else {
                binding.tvNoData.setVisibility(View.VISIBLE);
            }
        } else {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ITEM_DELETED_RESULT_CODE && resultCode == RESULT_OK) {
            adapter.notifyDataSetChanged();
            // Refresh data and update RecyclerView
            refreshItemList();
        }
    }

    private void refreshItemList() {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("itemList", "");

        if (!json.isEmpty()) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<LostFoundData>>() {}.getType();
            List<LostFoundData> itemList = gson.fromJson(json, type);

            if (itemList != null && !itemList.isEmpty()) {
                Collections.reverse(itemList);
                adapter = new ItemListAdapter(this, itemList);
                recyclerView.setAdapter(adapter);
            } else {
                binding.tvNoData.setVisibility(View.VISIBLE);
            }
        } else {
            binding.tvNoData.setVisibility(View.VISIBLE);
        }
    }
    @Override
    protected void onResume() {
        refreshItemList();
        super.onResume();
    }

    @Override
    protected void onRestart() {
        refreshItemList();
        super.onRestart();
    }

    @Override
    protected void onPause() {
        refreshItemList();
        super.onPause();
    }
}

