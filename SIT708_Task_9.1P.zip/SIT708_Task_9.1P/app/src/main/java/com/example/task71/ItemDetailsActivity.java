package com.example.task71;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.task71.databinding.ActivityItemDetailsBinding;
import com.google.gson.Gson;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ItemDetailsActivity extends AppCompatActivity {
    private ActivityItemDetailsBinding binding;
    private List<LostFoundData> itemList;
    private static final int ITEM_DELETED_RESULT_CODE = 1001;
    private ItemListAdapter adapter;


    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityItemDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        itemList = (List<LostFoundData>) getIntent().getSerializableExtra("itemList");
        position = getIntent().getIntExtra("position", -1);

        if (itemList != null && position != -1 && position < itemList.size()) {
            LostFoundData clickedItem = itemList.get(position);
            binding.tvName.setText("-- Name: "+clickedItem.getName());
            binding.tvPhone.setText("-- Phone: "+clickedItem.getPhone());
            binding.tvDescription.setText("-- Description: "+clickedItem.getDescription());
            binding.tvDate.setText("-- Date: "+getDateDifference(clickedItem.getDate()));
            binding.tvLocation.setText("-- Location: "+clickedItem.getLocation());
            binding.tvRemove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onDeleteButtonClick();
                }
            });
        } else {
            Toast.makeText(this, "Error: Unable to retrieve item details", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void onDeleteButtonClick() {
        if (position != -1 && position < itemList.size()) {
            itemList.remove(position);
            updateSharedPreferences();
            setResult(ITEM_DELETED_RESULT_CODE); // Set result indicating item deletion
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void updateSharedPreferences() {
        Gson gson = new Gson();
        String json = gson.toJson(itemList);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("itemList", json);
        editor.apply();
    }
//    private String getDateDifference(String date) {
//        // Parse the date from the string, assuming it's in the format "yyyy/MM/dd"
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
//        try {
//            Date itemDate = sdf.parse(date);
//            Date currentDate = new Date(); // Current date
//
//            // Calculate the difference in milliseconds
//            long differenceInMillis = currentDate.getTime() - itemDate.getTime();
//
//            // Convert milliseconds to days
//            long differenceInDays = TimeUnit.MILLISECONDS.toDays(differenceInMillis);
//
//            // Calculate difference in terms of months and years
//            long differenceInMonths = differenceInDays / 30;
//            long differenceInYears = differenceInMonths / 12;
//
//            // Format the output based on the difference
//            if (differenceInYears > 0) {
//                return differenceInYears + (differenceInYears == 1 ? " year ago" : " years ago");
//            } else if (differenceInMonths > 0) {
//                return differenceInMonths + (differenceInMonths == 1 ? " month ago" : " months ago");
//            } else if (differenceInDays > 0) {
//                return differenceInDays + (differenceInDays == 1 ? " day ago" : " days ago");
//            } else {
//                return "Today";
//            }
//        } catch (ParseException e) {
//            e.printStackTrace();
//            return date; // Return the original date if there's an error
//        }
//    }


    public static String getDateDifference(String date) {
        DateTimeFormatter formatter = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        }
        try {
            LocalDate itemDate = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                itemDate = LocalDate.parse(date, formatter);
            }
            LocalDate currentDate = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                currentDate = LocalDate.now();
            }

            // Calculate the difference using Period
            Period period = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                period = Period.between(itemDate, currentDate);
            }

            long years = 0;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                years = period.getYears();
            }
            long months = 0;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                months = period.getMonths();
            }
            long days = 0;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                days = period.getDays();
            }

            StringBuilder differenceString = new StringBuilder();

            if (years > 0) {
                differenceString.append(years).append(years == 1 ? " year " : " years ");
            }
            if (months > 0) {
                differenceString.append(months).append(months == 1 ? " month " : " months ");
            }
            if (days > 0) {
                differenceString.append(days).append(days == 1 ? " day " : " days ");
            }

            // If the difference string is empty, it means the date is today
            if (differenceString.length() == 0) {
                return "Today";
            }

            // Append "ago" at the end of the difference string
            differenceString.append("ago");

            return differenceString.toString().trim();
        } catch (Exception e) {
            e.printStackTrace();
            return date; // Return the original date if there's an error
        }
    }
}
